# Autonomous Job Agent MVP v0.2

A runnable candidate-specific job discovery, matching, policy, and application-planning service.

## What v0.2 adds

- Real **Greenhouse Job Board API** discovery connector.
- Real **Lever Postings API** discovery connector.
- Salary normalization to annual USD for Lever hourly/monthly/weekly/yearly ranges.
- Greenhouse pay-transparency enrichment when a public USD range is available.
- Deduplication through stable ATS source IDs.
- Continuous polling worker for configured employer boards.
- Greenhouse application-question planner that refuses to invent unknown required answers.
- Greenhouse browser form adapter that can fill a fully-known application plan and optionally submit it.
- Lever hosted-form adapter that inspects required fields at runtime, fills known profile answers, and blocks unknown/consent fields.
- Candidate contact details and two source resumes included as `resumes/java_resume.docx` and `resumes/ai_resume.docx`.

## Candidate rules included

- Search scope: United States nationwide
- Remote/hybrid/on-site: allowed
- Relocation: yes
- Minimum salary: $90,000/year
- Salary undisclosed: allowed
- U.S. work authorization: yes
- Sponsorship now/future: no
- Primary track: Java / Spring Boot / Full Stack / Backend / Microservices
- Secondary track: Generative AI / LLM / RAG / Agentic AI
- Prior-employer answers come from employment history rather than a hard-coded "No"

## Architecture

```text
Greenhouse public boards ─┐
                          ├─> normalize -> dedupe -> match -> policy -> application queue
Lever public sites ───────┘                                      |
                                                                 v
                                                     ATS application planner
                                                                 |
                                                                 v
                                                    browser form adapter
                                                                 |
                                           submitted / blocked / unsupported
```

## Why discovery uses APIs but submission uses the browser

Greenhouse and Lever make published job data publicly readable, which is excellent for low-latency discovery. Their direct application POST endpoints, however, require employer-side API credentials. A job seeker normally does not possess those keys. This project therefore uses public posting APIs for discovery and applicant-facing forms for submission.

The browser adapters **do not bypass CAPTCHA, MFA, bot challenges, or site restrictions**. Unknown required questions block the application instead of fabricating an answer.

## Configure monitored employers

Copy `.env.example` to `.env` and add ATS identifiers:

```env
GREENHOUSE_BOARDS_JSON={"company_board_token":"Company Name"}
LEVER_SITES_JSON={"company_lever_site":"Company Name"}
```

You can monitor many employers by adding more key/value pairs.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
playwright install chromium
cp .env.example .env
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs`.

Useful endpoints:

```text
POST /discover/greenhouse/{board_token}?company=Company%20Name
POST /discover/lever/{site}?company=Company%20Name
POST /discover/configured
POST /applications/greenhouse/plan-and-fill
POST /applications/lever/fill
GET  /jobs
GET  /applications
```

## Continuous mode

```bash
python -m app.worker
```

The worker checks every configured source at `POLL_SECONDS`, with a minimum interval of 60 seconds. Already-seen ATS IDs are ignored, so only newly discovered postings enter the matching/application pipeline.

## Application behavior

`AUTO_SUBMIT=false` remains the default. This is deliberate. Before switching it on for a specific ATS, run the browser adapter against real employer forms in dry-run mode and verify that every mapped field is correct.

The Greenhouse planner can automatically answer known questions such as U.S. work authorization, sponsorship, relocation, and prior employment. It blocks on unknown *required* questions and on data-processing/retention consent until a one-time consent policy is explicitly added to the source-of-truth candidate profile.

## Tests

```bash
pytest -q
```

## Next production steps

1. Add a verified employer-board registry or a licensed job-data provider so discovery is broad rather than limited to configured companies.
2. Harden Greenhouse/Lever selectors against real-world form variants and add integration fixtures.
3. Add Ashby and Workday discovery/application adapters.
4. Add resume tailoring with immutable fact constraints and generated-PDF/DOCX snapshots per application.
5. Add retries, queue workers, observability, email/status tracking, and audit logs.
6. Add explicit one-time policies for privacy consent, voluntary demographic questions, notice periods, salary expectations, travel percentage, and similar screening fields.

## Important limitation

No lawful applicant-side system can guarantee visibility into every U.S. job opening at the instant it is created. Public ATS feeds can be polled quickly, but private/internal jobs, sites without feeds, delayed syndication, and anti-automation controls remain outside that guarantee.
