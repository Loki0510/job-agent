from __future__ import annotations

import httpx

from app.connectors.base import DiscoveredJob
from app.services.salary import annualize_salary


class LeverConnector:
    """Discover published jobs from one public Lever site."""

    def __init__(self, site: str, company: str, timeout: float = 20.0):
        self.site = site.strip()
        self.company = company.strip()
        self.timeout = timeout

    async def discover(self) -> list[DiscoveredJob]:
        url = f"https://api.lever.co/v0/postings/{self.site}"
        async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
            response = await client.get(url, params={"mode": "json", "limit": 500})
            response.raise_for_status()
            payload = response.json()

        jobs: list[DiscoveredJob] = []
        for raw in payload:
            categories = raw.get("categories") or {}
            location = (categories.get("location") or "").strip()
            workplace_type = (raw.get("workplaceType") or "").lower()
            remote = workplace_type == "remote" or "remote" in location.lower()
            salary = raw.get("salaryRange") or {}
            interval = salary.get("interval")
            salary_min = annualize_salary(salary.get("min"), interval)
            salary_max = annualize_salary(salary.get("max"), interval)
            jobs.append(
                DiscoveredJob(
                    external_id=f"lever:{self.site}:{raw.get('id')}",
                    source="lever",
                    company=self.company,
                    title=(raw.get("text") or "").strip(),
                    location=location,
                    description=(raw.get("descriptionPlain") or raw.get("openingPlain") or "").strip(),
                    apply_url=(raw.get("applyUrl") or raw.get("hostedUrl") or "").strip(),
                    salary_min=salary_min,
                    salary_max=salary_max,
                    remote=remote,
                )
            )
        return jobs
