from __future__ import annotations

import html
import re
import httpx

from app.connectors.base import DiscoveredJob


_TAG_RE = re.compile(r"<[^>]+>")


def _plain(value: str | None) -> str:
    if not value:
        return ""
    return re.sub(r"\s+", " ", _TAG_RE.sub(" ", html.unescape(value))).strip()


class GreenhouseConnector:
    """Discover published jobs from one public Greenhouse job board."""

    def __init__(self, board_token: str, company: str, timeout: float = 20.0):
        self.board_token = board_token.strip()
        self.company = company.strip()
        self.timeout = timeout

    async def discover(self) -> list[DiscoveredJob]:
        url = f"https://boards-api.greenhouse.io/v1/boards/{self.board_token}/jobs"
        async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
            response = await client.get(url, params={"content": "true"})
            response.raise_for_status()
            payload = response.json()

            jobs: list[DiscoveredJob] = []
            for raw in payload.get("jobs", []):
                job_id = raw.get("id")
                if job_id is None:
                    continue

                salary_min = salary_max = None
                try:
                    detail = await client.get(
                        f"{url}/{job_id}", params={"pay_transparency": "true"}
                    )
                    if detail.is_success:
                        ranges = detail.json().get("pay_input_ranges") or []
                        usd = [r for r in ranges if (r.get("currency_type") or "").upper() == "USD"]
                        if usd:
                            # Greenhouse values are cents.
                            salary_min = min(int(r["min_cents"] / 100) for r in usd if r.get("min_cents") is not None)
                            salary_max = max(int(r["max_cents"] / 100) for r in usd if r.get("max_cents") is not None)
                except Exception:
                    # Salary enrichment must never prevent discovery.
                    pass

                location = ((raw.get("location") or {}).get("name") or "").strip()
                remote = "remote" in location.lower()
                description = _plain(raw.get("content"))
                jobs.append(
                    DiscoveredJob(
                        external_id=f"greenhouse:{self.board_token}:{job_id}",
                        source="greenhouse",
                        company=self.company,
                        title=(raw.get("title") or "").strip(),
                        location=location,
                        description=description,
                        apply_url=(raw.get("absolute_url") or "").strip(),
                        salary_min=salary_min,
                        salary_max=salary_max,
                        remote=remote,
                    )
                )
            return jobs
