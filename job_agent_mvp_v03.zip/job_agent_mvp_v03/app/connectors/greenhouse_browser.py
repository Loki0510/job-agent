from __future__ import annotations

from playwright.async_api import async_playwright
from app.connectors.browser import SubmitResult
from app.services.application_planner import ApplicationPlan


class GreenhouseBrowserApplicationConnector:
    """Fill a Greenhouse public application form from a prevalidated plan."""

    async def submit(self, apply_url: str, plan: ApplicationPlan, auto_submit: bool = False) -> SubmitResult:
        if plan.status != "ready":
            return SubmitResult(status="blocked", error="; ".join(plan.blockers))

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            try:
                await page.goto(apply_url, wait_until="domcontentloaded", timeout=45000)
                body = (await page.locator("body").inner_text()).lower()
                if any(x in body for x in ["captcha", "verify you are human", "security challenge"]):
                    return SubmitResult(status="blocked", error="Human verification/CAPTCHA detected; no bypass attempted.")

                for item in plan.fields:
                    selectors = [
                        f'[name="{item.name}"]',
                        f'input[name="{item.name}"]',
                        f'textarea[name="{item.name}"]',
                        f'select[name="{item.name}"]',
                    ]
                    locator = None
                    for selector in selectors:
                        loc = page.locator(selector)
                        if await loc.count():
                            locator = loc.first
                            break
                    if locator is None:
                        return SubmitResult(status="blocked", error=f"Could not locate required field: {item.label} ({item.name})")

                    if item.field_type == "input_file":
                        await locator.set_input_files(item.value)
                    elif item.field_type in {"multi_value_single_select", "multi_value_multi_select"}:
                        try:
                            await locator.select_option(label=item.value)
                        except Exception:
                            try:
                                await locator.select_option(value=item.value)
                            except Exception:
                                return SubmitResult(status="blocked", error=f"Could not select answer for: {item.label}")
                    else:
                        await locator.fill(item.value)

                if not auto_submit:
                    return SubmitResult(status="filled_dry_run", confirmation="All known required fields were filled; submission disabled.")

                submit = page.locator('button[type="submit"], input[type="submit"]').first
                if not await submit.count():
                    return SubmitResult(status="blocked", error="Submit control not found.")
                await submit.click()
                await page.wait_for_timeout(1500)
                text = (await page.locator("body").inner_text()).strip()
                lower = text.lower()
                if "thank" in lower or "application" in lower and "received" in lower:
                    return SubmitResult(status="submitted", confirmation=text[:1000])
                return SubmitResult(status="submitted_unconfirmed", confirmation=text[:1000])
            except Exception as exc:
                return SubmitResult(status="error", error=str(exc))
            finally:
                await browser.close()
