from __future__ import annotations

import re
from pathlib import Path
from playwright.async_api import async_playwright

from app.connectors.browser import SubmitResult
from app.core.profile import CandidateProfile
from app.services.questions import UnknownQuestion, answer_screening_question


class LeverBrowserApplicationConnector:
    """Applicant-side Lever hosted-form adapter.

    Lever's public postings API does not expose custom application questions, so
    this adapter inspects required controls on the hosted form. Unknown required
    questions block submission instead of being guessed.
    """

    def __init__(self, profile: CandidateProfile):
        self.profile = profile

    async def _label_for(self, page, locator) -> str:
        element_id = await locator.get_attribute("id")
        if element_id:
            label = page.locator(f'label[for="{element_id}"]')
            if await label.count():
                return (await label.first.inner_text()).strip()
        aria = await locator.get_attribute("aria-label")
        if aria:
            return aria.strip()
        placeholder = await locator.get_attribute("placeholder")
        if placeholder:
            return placeholder.strip()
        name = await locator.get_attribute("name")
        return (name or "Required field").strip()

    async def submit(self, apply_url: str, company: str, resume_path: str, auto_submit: bool = False) -> SubmitResult:
        first, *rest = self.profile.name.split()
        full_name = self.profile.name
        basics = {
            "name": full_name,
            "fullname": full_name,
            "full_name": full_name,
            "firstname": first,
            "first_name": first,
            "lastname": " ".join(rest),
            "last_name": " ".join(rest),
            "email": self.profile.email,
            "phone": self.profile.phone,
            "linkedin": self.profile.linkedin,
        }
        resume = str(Path(resume_path).resolve())

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            try:
                await page.goto(apply_url, wait_until="domcontentloaded", timeout=45000)
                body = (await page.locator("body").inner_text()).lower()
                if any(x in body for x in ["captcha", "verify you are human", "security challenge"]):
                    return SubmitResult(status="blocked", error="Human verification/CAPTCHA detected; no bypass attempted.")

                # Upload resume first when the form exposes a file input.
                file_inputs = page.locator('input[type="file"]')
                if await file_inputs.count():
                    await file_inputs.first.set_input_files(resume)

                controls = page.locator('input[required], textarea[required], select[required]')
                blockers: list[str] = []
                for i in range(await controls.count()):
                    loc = controls.nth(i)
                    if not await loc.is_visible():
                        continue
                    tag = await loc.evaluate("el => el.tagName.toLowerCase()")
                    input_type = ((await loc.get_attribute("type")) or "").lower()
                    if input_type in {"hidden", "file", "submit", "button"}:
                        continue
                    if input_type in {"checkbox", "radio"} and await loc.is_checked():
                        continue
                    try:
                        current = await loc.input_value()
                    except Exception:
                        current = ""
                    if current:
                        continue

                    name = ((await loc.get_attribute("name")) or "").lower()
                    compact = re.sub(r"[^a-z_]", "", name)
                    value = None
                    for key, candidate in basics.items():
                        if key in compact and candidate:
                            value = candidate
                            break

                    label = await self._label_for(page, loc)
                    if value is None:
                        try:
                            value = answer_screening_question(self.profile, label, company)
                        except UnknownQuestion:
                            value = None

                    if value is None:
                        blockers.append(label)
                        continue

                    if tag == "select":
                        try:
                            await loc.select_option(label=value)
                        except Exception:
                            blockers.append(label)
                    elif input_type == "radio":
                        # Prefer a radio option whose nearby label text equals the answer.
                        group = await loc.get_attribute("name")
                        options = page.locator(f'input[type="radio"][name="{group}"]') if group else loc
                        selected = False
                        for j in range(await options.count()):
                            option = options.nth(j)
                            option_label = (await self._label_for(page, option)).lower()
                            option_value = ((await option.get_attribute("value")) or "").lower()
                            if value.lower() in {option_label, option_value} or value.lower() in option_label:
                                await option.check()
                                selected = True
                                break
                        if not selected:
                            blockers.append(label)
                    elif input_type == "checkbox":
                        # Never infer acceptance of terms/privacy consent from unrelated profile fields.
                        blockers.append(label)
                    else:
                        await loc.fill(value)

                if blockers:
                    return SubmitResult(status="blocked", error="Unknown or unapproved required fields: " + "; ".join(sorted(set(blockers))))

                if not auto_submit:
                    return SubmitResult(status="filled_dry_run", confirmation="Known required Lever fields filled; submission disabled.")

                submit = page.locator('button[type="submit"], input[type="submit"]').first
                if not await submit.count():
                    return SubmitResult(status="blocked", error="Submit control not found.")
                await submit.click()
                await page.wait_for_timeout(1500)
                text = (await page.locator("body").inner_text()).strip()
                lower = text.lower()
                if "thank" in lower or ("application" in lower and "received" in lower):
                    return SubmitResult(status="submitted", confirmation=text[:1000])
                return SubmitResult(status="submitted_unconfirmed", confirmation=text[:1000])
            except Exception as exc:
                return SubmitResult(status="error", error=str(exc))
            finally:
                await browser.close()
