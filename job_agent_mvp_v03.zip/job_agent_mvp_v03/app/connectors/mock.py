from app.connectors.base import DiscoveredJob


class MockConnector:
    async def discover(self) -> list[DiscoveredJob]:
        return [
            DiscoveredJob(
                external_id="demo-001",
                source="mock",
                company="Example Financial",
                title="Senior Java Backend Engineer",
                location="United States - Remote",
                description="Java Spring Boot microservices Kafka REST APIs Kubernetes Azure SQL",
                apply_url="https://example.com/jobs/demo-001",
                salary_min=120000,
                salary_max=155000,
                remote=True,
            ),
            DiscoveredJob(
                external_id="demo-002",
                source="mock",
                company="Example AI",
                title="Generative AI Engineer",
                location="New York, NY",
                description="Python LLM RAG OpenAI Azure OpenAI vector databases prompt engineering",
                apply_url="https://example.com/jobs/demo-002",
                salary_min=135000,
                salary_max=180000,
            ),
        ]
