from __future__ import annotations

import json
from app.core.config import settings
from app.connectors.greenhouse import GreenhouseConnector
from app.connectors.lever import LeverConnector


def _json_map(raw: str) -> dict[str, str]:
    try:
        value = json.loads(raw or "{}")
        if not isinstance(value, dict):
            return {}
        return {str(k): str(v) for k, v in value.items() if k and v}
    except json.JSONDecodeError:
        return {}


def configured_connectors():
    result = []
    for board_token, company in _json_map(settings.greenhouse_boards_json).items():
        result.append(GreenhouseConnector(board_token=board_token, company=company))
    for site, company in _json_map(settings.lever_sites_json).items():
        result.append(LeverConnector(site=site, company=company))
    return result
