from app.core.profile import CandidateProfile


class UnknownQuestion(Exception):
    pass


def answer_screening_question(profile: CandidateProfile, question: str, company: str) -> str:
    q = question.lower().strip()

    if "authorized" in q and "united states" in q:
        return "Yes" if profile.authorized_us else "No"
    if "sponsorship" in q:
        return "Yes" if profile.requires_sponsorship_now_or_future else "No"
    if "relocate" in q:
        return "Yes" if profile.willing_to_relocate else "No"
    if "previously worked" in q or "worked for" in q:
        past = any(p.lower() in company.lower() or company.lower() in p.lower() for p in profile.past_employers)
        return "Yes" if past else "No"
    if "certify" in q and "accurate" in q:
        # Caller must only use this after validating fields against the source-of-truth profile.
        return "Yes"

    raise UnknownQuestion(question)
