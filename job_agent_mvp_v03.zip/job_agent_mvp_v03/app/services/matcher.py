import re
from dataclasses import dataclass
from app.core.profile import CandidateProfile


@dataclass
class MatchResult:
    score: float
    matched_skills: list[str]
    title_match: bool
    ai_track: bool


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip()


def match_job(profile: CandidateProfile, title: str, description: str) -> MatchResult:
    title_n = _norm(title)
    body = _norm(f"{title} {description}")

    primary = any(_norm(t) in title_n or title_n in _norm(t) for t in profile.primary_titles)
    secondary = any(_norm(t) in title_n or title_n in _norm(t) for t in profile.secondary_titles)

    matched = [s for s in profile.skills if _norm(s) in body]
    skill_score = min(len(matched) / 10.0, 1.0)
    title_score = 1.0 if (primary or secondary) else 0.0

    # Simple transparent MVP scoring. Replace with embeddings/LLM reranking later.
    score = round((0.55 * title_score) + (0.45 * skill_score), 3)
    return MatchResult(score=score, matched_skills=matched, title_match=(primary or secondary), ai_track=secondary)
