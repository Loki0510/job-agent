from dataclasses import dataclass
from app.core.profile import CandidateProfile
from app.services.matcher import MatchResult


@dataclass
class PolicyDecision:
    action: str  # apply | skip | review
    reason: str
    resume_profile: str


def decide(profile: CandidateProfile, match: MatchResult, company: str, salary_min: int | None, salary_max: int | None, min_fit_score: float) -> PolicyDecision:
    if salary_max is not None and salary_max < profile.min_salary_usd:
        return PolicyDecision("skip", f"Maximum salary ${salary_max:,} is below ${profile.min_salary_usd:,}.", "ai" if match.ai_track else "java")

    if match.score < min_fit_score:
        return PolicyDecision("skip", f"Fit score {match.score:.2f} is below threshold {min_fit_score:.2f}.", "ai" if match.ai_track else "java")

    # Prior-employer handling must be answered truthfully at application time.
    if any(p.lower() in company.lower() or company.lower() in p.lower() for p in profile.past_employers):
        reason = "Eligible, but application must answer prior-employment questions using employment history."
    else:
        reason = "Eligible under title/skills/location/salary rules."

    return PolicyDecision("apply", reason, "ai" if match.ai_track else "java")
