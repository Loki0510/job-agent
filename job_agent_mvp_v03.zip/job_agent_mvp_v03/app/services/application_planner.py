from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import httpx

from app.core.profile import CandidateProfile
from app.services.questions import UnknownQuestion, answer_screening_question


@dataclass
class PlannedField:
    name: str
    label: str
    field_type: str
    value: str


@dataclass
class ApplicationPlan:
    status: str  # ready | blocked
    fields: list[PlannedField] = field(default_factory=list)
    blockers: list[str] = field(default_factory=list)


class GreenhouseApplicationPlanner:
    """Build a truthful application plan from Greenhouse's public question schema.

    The public API exposes questions but does not allow applicants to POST an
    application without the employer's Job Board API key. Submission is therefore
    performed by the public browser form adapter.
    """

    def __init__(self, profile: CandidateProfile, board_token: str, job_id: str | int, company: str):
        self.profile = profile
        self.board_token = board_token
        self.job_id = str(job_id)
        self.company = company

    async def build(self, resume_path: str) -> ApplicationPlan:
        url = f"https://boards-api.greenhouse.io/v1/boards/{self.board_token}/jobs/{self.job_id}"
        async with httpx.AsyncClient(timeout=20.0, follow_redirects=True) as client:
            response = await client.get(url, params={"questions": "true"})
            response.raise_for_status()
            data = response.json()

        first, *rest = self.profile.name.split()
        basics = {
            "first_name": first,
            "last_name": " ".join(rest),
            "email": self.profile.email,
            "phone": self.profile.phone,
            "linkedin": self.profile.linkedin,
        }
        plan = ApplicationPlan(status="ready")
        resume = str(Path(resume_path).resolve())

        questions = list(data.get("questions") or []) + list(data.get("location_questions") or [])
        for question in questions:
            label = (question.get("label") or "").strip()
            required = bool(question.get("required"))
            fields = question.get("fields") or []
            answered = False

            for f in fields:
                name = str(f.get("name") or "")
                field_type = str(f.get("type") or "")
                value: str | None = None

                if name in basics and basics[name]:
                    value = basics[name]
                elif field_type == "input_file" and "resume" in name.lower():
                    value = resume
                elif "resume_text" in name.lower():
                    # Prefer file upload. Text resume is an alternative field.
                    continue
                else:
                    try:
                        value = answer_screening_question(self.profile, label, self.company)
                    except UnknownQuestion:
                        value = None

                if value is not None:
                    plan.fields.append(PlannedField(name=name, label=label, field_type=field_type, value=value))
                    answered = True
                    break

            if required and not answered:
                plan.blockers.append(f"Unknown required question: {label}")

        # Do not infer legal/privacy consent. It needs a one-time explicit policy.
        for item in data.get("data_compliance") or []:
            if item.get("requires_consent") or item.get("requires_processing_consent") or item.get("requires_retention_consent"):
                plan.blockers.append("Application requires data-processing/retention consent not present in the candidate profile.")
                break

        if plan.blockers:
            plan.status = "blocked"
        return plan
