from __future__ import annotations


def annualize_salary(value: float | int | None, interval: str | None) -> int | None:
    if value is None:
        return None
    interval_n = (interval or "year").lower().strip()
    multipliers = {
        "year": 1,
        "yearly": 1,
        "annual": 1,
        "month": 12,
        "monthly": 12,
        "week": 52,
        "weekly": 52,
        "day": 260,
        "daily": 260,
        "hour": 2080,
        "hourly": 2080,
    }
    multiplier = multipliers.get(interval_n)
    if multiplier is None:
        return None
    return int(round(float(value) * multiplier))
