from sqlalchemy import select
from app.core.config import settings
from app.core.profile import PROFILE
from app.models.db import SessionLocal
from app.models.job import Job, Application
from app.services.matcher import match_job
from app.services.policy import decide


async def ingest_jobs(connector) -> dict:
    discovered = await connector.discover()
    created = applied = skipped = 0

    with SessionLocal() as db:
        for item in discovered:
            if db.scalar(select(Job).where(Job.external_id == item.external_id)):
                continue

            match = match_job(PROFILE, item.title, item.description)
            decision = decide(PROFILE, match, item.company, item.salary_min, item.salary_max, settings.min_fit_score)

            job = Job(
                external_id=item.external_id,
                source=item.source,
                company=item.company,
                title=item.title,
                location=item.location,
                description=item.description,
                apply_url=item.apply_url,
                salary_min=item.salary_min,
                salary_max=item.salary_max,
                remote=item.remote,
                fit_score=match.score,
                decision=decision.action,
                decision_reason=decision.reason,
            )
            db.add(job)
            created += 1

            if decision.action == "apply":
                db.add(Application(
                    job_external_id=item.external_id,
                    company=item.company,
                    title=item.title,
                    status="queued" if not settings.auto_submit else "ready_to_submit",
                    resume_profile=decision.resume_profile,
                ))
                applied += 1
            else:
                skipped += 1

        db.commit()

    return {"discovered": len(discovered), "created": created, "queued": applied, "skipped": skipped}
