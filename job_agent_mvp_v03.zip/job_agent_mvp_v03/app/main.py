from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from app.models.db import Base, engine, SessionLocal
from app.models.job import Job, Application
from app.connectors.mock import MockConnector
from app.connectors.greenhouse import GreenhouseConnector
from app.connectors.lever import LeverConnector
from app.connectors.registry import configured_connectors
from app.services.orchestrator import ingest_jobs
from app.core.profile import PROFILE
from app.core.config import settings
from app.services.application_planner import GreenhouseApplicationPlanner
from app.connectors.greenhouse_browser import GreenhouseBrowserApplicationConnector
from app.connectors.lever_browser import LeverBrowserApplicationConnector

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Autonomous Job Agent MVP", version="0.2.0")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/profile")
def profile():
    return PROFILE.model_dump()


@app.post("/discover/demo")
async def discover_demo():
    return await ingest_jobs(MockConnector())


@app.post("/discover/greenhouse/{board_token}")
async def discover_greenhouse(board_token: str, company: str):
    try:
        return await ingest_jobs(GreenhouseConnector(board_token=board_token, company=company))
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/discover/lever/{site}")
async def discover_lever(site: str, company: str):
    try:
        return await ingest_jobs(LeverConnector(site=site, company=company))
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/discover/configured")
async def discover_configured():
    summary = {"sources": 0, "discovered": 0, "created": 0, "queued": 0, "skipped": 0}
    for connector in configured_connectors():
        result = await ingest_jobs(connector)
        summary["sources"] += 1
        for key in ("discovered", "created", "queued", "skipped"):
            summary[key] += result[key]
    return summary


class GreenhouseApplyRequest(BaseModel):
    board_token: str
    job_id: str
    company: str
    apply_url: str
    resume_profile: str = "java"
    submit: bool = False


class LeverApplyRequest(BaseModel):
    company: str
    apply_url: str
    resume_profile: str = "java"
    submit: bool = False


@app.post("/applications/greenhouse/plan-and-fill")
async def greenhouse_plan_and_fill(req: GreenhouseApplyRequest):
    if req.resume_profile not in {"java", "ai"}:
        raise HTTPException(status_code=400, detail="resume_profile must be java or ai")
    resume_path = f"resumes/{req.resume_profile}_resume.docx"
    try:
        planner = GreenhouseApplicationPlanner(
            profile=PROFILE,
            board_token=req.board_token,
            job_id=req.job_id,
            company=req.company,
        )
        plan = await planner.build(resume_path=resume_path)
        if plan.status != "ready":
            return {
                "status": "blocked",
                "blockers": plan.blockers,
                "planned_fields": [f.__dict__ for f in plan.fields],
            }
        connector = GreenhouseBrowserApplicationConnector()
        result = await connector.submit(
            apply_url=req.apply_url,
            plan=plan,
            auto_submit=bool(req.submit and settings.auto_submit),
        )
        return {
            "status": result.status,
            "confirmation": result.confirmation,
            "error": result.error,
            "planned_fields": [f.__dict__ for f in plan.fields],
            "auto_submit_enabled": settings.auto_submit,
        }
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/applications/lever/fill")
async def lever_fill(req: LeverApplyRequest):
    if req.resume_profile not in {"java", "ai"}:
        raise HTTPException(status_code=400, detail="resume_profile must be java or ai")
    resume_path = f"resumes/{req.resume_profile}_resume.docx"
    try:
        connector = LeverBrowserApplicationConnector(PROFILE)
        result = await connector.submit(
            apply_url=req.apply_url,
            company=req.company,
            resume_path=resume_path,
            auto_submit=bool(req.submit and settings.auto_submit),
        )
        return {
            "status": result.status,
            "confirmation": result.confirmation,
            "error": result.error,
            "auto_submit_enabled": settings.auto_submit,
        }
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get("/jobs")
def jobs():
    with SessionLocal() as db:
        rows = db.scalars(select(Job).order_by(Job.id.desc())).all()
        return [
            {
                "external_id": j.external_id,
                "source": j.source,
                "company": j.company,
                "title": j.title,
                "location": j.location,
                "salary_min": j.salary_min,
                "salary_max": j.salary_max,
                "fit_score": j.fit_score,
                "decision": j.decision,
                "reason": j.decision_reason,
                "apply_url": j.apply_url,
            }
            for j in rows
        ]


@app.get("/applications")
def applications():
    with SessionLocal() as db:
        rows = db.scalars(select(Application).order_by(Application.id.desc())).all()
        return [
            {
                "job_external_id": a.job_external_id,
                "company": a.company,
                "title": a.title,
                "status": a.status,
                "resume_profile": a.resume_profile,
            }
            for a in rows
        ]
