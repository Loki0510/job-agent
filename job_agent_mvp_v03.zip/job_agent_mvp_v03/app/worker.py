import asyncio
from app.core.config import settings
from app.connectors.registry import configured_connectors
from app.services.orchestrator import ingest_jobs


async def run_once():
    summary = {"sources": 0, "discovered": 0, "created": 0, "queued": 0, "skipped": 0}
    for connector in configured_connectors():
        result = await ingest_jobs(connector)
        summary["sources"] += 1
        for key in ("discovered", "created", "queued", "skipped"):
            summary[key] += result[key]
    return summary


async def main():
    while True:
        try:
            print(await run_once(), flush=True)
        except Exception as exc:
            print({"error": str(exc)}, flush=True)
        await asyncio.sleep(max(settings.poll_seconds, 60))


if __name__ == "__main__":
    asyncio.run(main())
