from pydantic import BaseModel, Field
from typing import List, Optional


class CandidateProfile(BaseModel):
    name: str = "Lokesh Vinnakota"
    country: str = "US"
    email: str = "lvinnakota282@gmail.com"
    phone: str = "+1 (283)-210-6973"
    linkedin: str = "http://www.linkedin.com/in/lokv"
    locations: List[str] = Field(default_factory=lambda: ["United States"])
    remote_ok: bool = True
    hybrid_ok: bool = True
    onsite_ok: bool = True
    willing_to_relocate: bool = True
    min_salary_usd: int = 90000
    authorized_us: bool = True
    requires_sponsorship_now_or_future: bool = False
    years_experience: float = 5.0
    primary_titles: List[str] = Field(default_factory=lambda: [
        "Senior Full Stack Java Developer",
        "Full Stack Java Developer",
        "Senior Java Developer",
        "Java Developer",
        "Java Software Engineer",
        "Senior Software Engineer Java",
        "Backend Java Developer",
        "Java Backend Engineer",
        "Backend Software Engineer",
        "Spring Boot Developer",
        "Java Microservices Developer",
        "Microservices Engineer",
        "Full Stack Software Engineer",
        "Java J2EE Developer",
        "Java API Developer",
        "Java Cloud Developer",
        "Azure Java Developer",
    ])
    secondary_titles: List[str] = Field(default_factory=lambda: [
        "Generative AI Engineer",
        "GenAI Engineer",
        "AI Engineer",
        "LLM Engineer",
        "Agentic AI Engineer",
        "RAG Engineer",
        "Applied AI Engineer",
        "AI Software Engineer",
        "AI LLM Backend Engineer",
        "Generative AI Developer",
        "AI Solutions Engineer",
    ])
    skills: List[str] = Field(default_factory=lambda: [
        "java", "spring", "spring boot", "microservices", "hibernate", "jpa",
        "rest", "soap", "react", "angular", "javascript", "typescript",
        "sql", "oracle", "mysql", "postgresql", "mongodb", "kafka", "flink",
        "azure", "aks", "docker", "kubernetes", "jenkins", "maven", "python",
        "llm", "generative ai", "rag", "openai", "azure openai", "aws bedrock",
        "pinecone", "faiss", "prompt engineering", "agentic ai"
    ])
    past_employers: List[str] = Field(default_factory=lambda: [
        "U.S. Bank", "US Bank", "Optum", "UnitedHealth Group", "Idea Labs", "HUDA Infotech"
    ])
    education: List[str] = Field(default_factory=lambda: [
        "Master's - University of Cincinnati",
        "Bachelor's - Vignan's Foundation for Science, Technology & Research (VFSTR), India",
    ])


PROFILE = CandidateProfile()
