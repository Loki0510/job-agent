from app.services.salary import annualize_salary


def test_hourly_salary_annualizes():
    assert annualize_salary(50, "hour") == 104000


def test_monthly_salary_annualizes():
    assert annualize_salary(10000, "month") == 120000
