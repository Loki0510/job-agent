from app.core.profile import PROFILE
from app.services.questions import answer_screening_question


def test_auth_answers():
    assert answer_screening_question(PROFILE, "Are you legally authorized to work in the United States?", "Acme") == "Yes"
    assert answer_screening_question(PROFILE, "Will you now or in the future require sponsorship?", "Acme") == "No"


def test_prior_employer_truthful():
    assert answer_screening_question(PROFILE, "Have you previously worked for this company?", "UnitedHealth Group") == "Yes"
