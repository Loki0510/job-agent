from app.core.profile import PROFILE
from app.services.matcher import match_job
from app.services.policy import decide


def test_java_role_applies():
    m = match_job(PROFILE, "Senior Java Backend Engineer", "Java Spring Boot Kafka Kubernetes REST Azure SQL")
    d = decide(PROFILE, m, "Example Corp", 120000, 150000, 0.72)
    assert d.action == "apply"
    assert d.resume_profile == "java"


def test_low_salary_skips():
    m = match_job(PROFILE, "Senior Java Developer", "Java Spring Boot microservices")
    d = decide(PROFILE, m, "Example Corp", 70000, 85000, 0.72)
    assert d.action == "skip"
