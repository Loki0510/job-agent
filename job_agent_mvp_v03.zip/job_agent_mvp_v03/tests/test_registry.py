from app.connectors.registry import _json_map


def test_json_map():
    assert _json_map('{"acme":"Acme Corp"}') == {"acme": "Acme Corp"}
    assert _json_map('not-json') == {}
